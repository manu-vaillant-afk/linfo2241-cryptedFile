# Client code
- All sources code is in "src" folder
- "temp" directory is used for storing temporary files during decryption
- "10k-most-common_filered.txt" is used for the optimized version
- Before running client code, don't forget to create these directory and to add their associated files. Create these directories in root folder (same level as "src") : 
    - Files-100KB
    - Files-5MB
    - Files-20KB
    - Files-50KB
    - Files-50MB