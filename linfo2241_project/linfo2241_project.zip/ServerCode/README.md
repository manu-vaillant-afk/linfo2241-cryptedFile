# Server code
- All sources code is in "src" folder
- "temp" directory is used for storing temporary files during decryption
- "10k-most-common_filered.txt" is used for the optimized version